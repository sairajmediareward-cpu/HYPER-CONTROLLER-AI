# Hyper Controller AI - Android

Android port of your v7 Windows gesture app. Same gesture vocabulary, same engine
(`GestureEngine.kt` is a line-by-line port of `gesture_engine.py`). Everything runs on the phone.

## Get the APK (pick one)

**A. Android Studio (easiest)**
1. Install Android Studio, choose *Open* and select this folder. Let Gradle sync (needs internet once;
   it also downloads MediaPipe's `hand_landmarker.task` model into `app/src/main/assets/`).
2. *Build > Build APK(s)*. File: `app/build/outputs/apk/debug/app-debug.apk`.

**B. No installs - GitHub**
1. Create a free GitHub repo and upload this folder's contents.
2. Open the *Actions* tab > *Build APK* > run it. Download `HyperControllerAI-debug-apk` when it finishes.

Then copy the APK to your phone and install it (allow "install unknown apps").

## First run on the phone
1. Open the app > **1. Turn on accessibility service** > Hyper Controller AI > On.
2. **2. Start camera tracking** (allow camera + notifications).
3. **3. Enable gesture control**. It always starts OFF.

## How Windows features map to Android
| Windows | Android |
|---|---|
| Move cursor | On-screen cursor dot |
| Left click / drag | Tap / drag (Accessibility gestures) |
| Right click | Long-press |
| Scroll | Swipe at cursor |
| Zoom (two hands) | Pinch gesture |
| Maximize / Minimize / Show desktop | Recents / Home / Home |
| Play-pause, next/prev, volume | Media keys / volume |
| Ctrl+Alt+X emergency stop | Notification "Stop" / "Pause control" buttons |

## Not ported (yet)
Licence-key check, custom-gesture recorder, web dashboard, per-gesture settings screen
(defaults from `default_mappings()` are used). Portrait only. Needs Android 8.0+ and a front camera.
Games and apps that block accessibility taps will ignore it.

## Status
Written without access to a compiler or device, so it has not been built or tested. If Gradle reports an error,
send me the message and I'll fix it.
