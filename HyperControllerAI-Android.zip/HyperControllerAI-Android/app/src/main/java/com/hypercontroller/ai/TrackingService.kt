package com.hypercontroller.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Front camera -> MediaPipe hand landmarks -> GestureEngine -> ControlService. All on-device. */
class TrackingService : LifecycleService() {
    companion object {
        const val ACTION_STOP = "hc.stop"
        const val ACTION_TOGGLE = "hc.toggle"
        private const val CHANNEL = "hc_tracking"
        @Volatile var running = false
    }

    private val engine = GestureEngine()
    private val main = Handler(Looper.getMainLooper())
    private var exec: ExecutorService? = null
    private var landmarker: HandLandmarker? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_TOGGLE -> {
                Bridge.controlEnabled = !Bridge.controlEnabled
                notifyNow()
                return START_NOT_STICKY
            }
        }
        if (!running) start()
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        fun act(a: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, TrackingService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val state = if (Bridge.controlEnabled) "Control ON" else "Control OFF"
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Hyper Controller AI - $state")
            .setContentText("Camera is tracking your hand")
            .setOngoing(true)
            .addAction(0, if (Bridge.controlEnabled) "Pause control" else "Resume control", act(ACTION_TOGGLE, 1))
            .addAction(0, "Stop", act(ACTION_STOP, 2))
            .build()
    }

    private fun notifyNow() =
        getSystemService(NotificationManager::class.java).notify(1, notification())

    private fun start() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Hand tracking", NotificationManager.IMPORTANCE_LOW)
        )
        ServiceCompat.startForeground(this, 1, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        running = true

        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setResultListener { r, _ -> onResult(r) }
            .setErrorListener { e -> Log.e("HC", "MediaPipe error", e) }
            .build()
        landmarker = HandLandmarker.createFromOptions(this, opts)

        val e = Executors.newSingleThreadExecutor()
        exec = e
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            @Suppress("DEPRECATION")
            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(e) { analyze(it) }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val raw = proxy.toBitmap()
            val m = Matrix().apply { postRotate(proxy.imageInfo.rotationDegrees.toFloat()) }
            val upright = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            landmarker?.detectAsync(BitmapImageBuilder(upright).build(), SystemClock.uptimeMillis())
        } catch (t: Throwable) {
            Log.e("HC", "frame failed", t)
        } finally {
            proxy.close()
        }
    }

    private fun onResult(r: HandLandmarkerResult) {
        // Front camera is not mirrored: flip x once here (the Windows app flipped the frame).
        val hands = r.landmarks().map { h -> h.map { P(1f - it.x(), it.y()) } }
        val intent = engine.update(hands, SystemClock.uptimeMillis())
        main.post { ControlService.instance?.handle(intent) }
    }

    override fun onDestroy() {
        running = false
        Bridge.controlEnabled = false
        landmarker?.close(); landmarker = null
        exec?.shutdown()
        ControlService.instance?.releaseAll()
        super.onDestroy()
    }
}
