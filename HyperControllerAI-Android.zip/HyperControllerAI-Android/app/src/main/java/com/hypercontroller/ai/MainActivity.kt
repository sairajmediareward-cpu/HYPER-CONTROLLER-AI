package com.hypercontroller.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var control: Switch
    private val ui = Handler(Looper.getMainLooper())

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startTracking() }

    private val ticker = object : Runnable {
        override fun run() {
            val a11y = if (ControlService.instance != null) "ON" else "OFF  (step 1)"
            val trk = if (TrackingService.running) "RUNNING" else "stopped"
            status.text = "Accessibility service: $a11y\nCamera tracking: $trk\n" +
                "Pose: ${Bridge.pose}   Action: ${Bridge.label}"
            control.isChecked = Bridge.controlEnabled
            ui.postDelayed(this, 300)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
            .also { col.addView(it, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT) }

        col.addView(TextView(this).apply { text = "Hyper Controller AI"; textSize = 24f })
        status = TextView(this).apply { textSize = 15f; setPadding(0, pad, 0, pad) }
        col.addView(status)

        btn("1. Turn on accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("2. Start camera tracking") {
            val need = mutableListOf(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
            permLauncher.launch(need.toTypedArray())
        }
        control = Switch(this).apply {
            text = "3. Enable gesture control (starts OFF)"
            setPadding(0, pad, 0, pad)
            setOnClickListener { Bridge.controlEnabled = isChecked }
        }
        col.addView(control)
        btn("Stop tracking") { stopService(Intent(this, TrackingService::class.java)) }

        col.addView(TextView(this).apply {
            setPadding(0, pad, 0, 0)
            text = """
GESTURES (hold the phone upright, front camera sees your hand ~arm's length away)

Index finger only - move cursor
L-shape (thumb+index), quick flick - tap
L-shape, hold 0.4 s - drag
Horns (index+pinky) - long-press (right click)
Index+middle, move up/down - scroll
Three fingers, swipe left/right - previous/next track
Four fingers, raise/lower - Recents / Home
Thumb+pinky, raise/lower - volume up/down
Thumb up - play/pause
Both hands open palm - Home
Both hands pinching, apart/together - zoom
Fist or open palm - rest (does nothing)

SAFETY: control starts OFF. Use the notification's "Pause control" or "Stop" button, or the switch above, at any time. Closing tracking releases any held drag.
            """.trimIndent()
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun startTracking() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        ContextCompat.startForegroundService(this, Intent(this, TrackingService::class.java))
    }

    override fun onResume() { super.onResume(); ui.post(ticker) }
    override fun onPause() { ui.removeCallbacks(ticker); super.onPause() }
}
