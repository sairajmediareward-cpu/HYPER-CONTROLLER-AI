package com.hypercontroller.ai

/** Tiny shared state between the UI, tracker and control service. Control always starts OFF. */
object Bridge {
    @Volatile var controlEnabled = false
    @Volatile var pose = "-"
    @Volatile var label = "IDLE"
}
