package com.hypercontroller.ai

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Direct Kotlin port of gesture_engine.py (v7). Landmarks are already mirrored. */
data class P(val x: Float, val y: Float)

private const val WRIST = 0
private const val THUMB_MCP = 2
private const val THUMB_TIP = 4
private const val INDEX_MCP = 5
private const val INDEX_TIP = 8
private const val MIDDLE_MCP = 9

private val TIPS = intArrayOf(8, 12, 16, 20)
private val PIPS = intArrayOf(6, 10, 14, 18)

fun dist(a: P, b: P): Float = hypot((a.x - b.x).toDouble(), (a.y - b.y).toDouble()).toFloat()
private fun handScale(lm: List<P>) = max(dist(lm[WRIST], lm[MIDDLE_MCP]), 1e-6f)

/** [thumb, index, middle, ring, pinky] - rotation tolerant. */
fun fingersExtended(lm: List<P>): List<Boolean> {
    val scale = handScale(lm)
    val wrist = lm[WRIST]
    val thumb = dist(lm[THUMB_TIP], wrist) > dist(lm[THUMB_MCP], wrist) * 1.12f &&
        dist(lm[THUMB_TIP], lm[INDEX_MCP]) / scale > 0.55f
    val out = mutableListOf(thumb)
    for (i in TIPS.indices) out.add(dist(lm[TIPS[i]], wrist) > dist(lm[PIPS[i]], wrist) * 1.06f)
    return out
}

fun detectPose(lm: List<P>, pinchOn: Float = 0.55f, lThumbMin: Float = 0.62f): String {
    val scale = handScale(lm)
    val wrist = lm[WRIST]
    val ext = fingersExtended(lm)
    val (thumb, index, middle, ring, pinky) = ext
    val pinchI = dist(lm[THUMB_TIP], lm[INDEX_TIP]) / scale
    val thumbSpread = dist(lm[THUMB_TIP], lm[INDEX_MCP]) / scale
    val reachI = dist(lm[INDEX_TIP], wrist) / scale

    if (!ring && !pinky && pinchI < pinchOn && reachI > 1.25f) return "PINCH_INDEX"
    if (thumb && index && !middle && !ring && !pinky)
        return if (thumbSpread >= lThumbMin) "L_SHAPE" else "UNKNOWN"
    if (index && !middle && !ring && !pinky && !thumb) return "POINT"
    if (index && pinky && !middle && !ring && !thumb) return "HORNS"
    if (index && middle && !ring && !pinky) return "TWO_FINGER"
    if (index && middle && ring && !pinky) return "THREE_FINGER"
    if (index && middle && ring && pinky && !thumb) return "FOUR_FINGER"
    if (ext.all { it }) return "OPEN_PALM"
    if (ext.none { it }) return "FIST"
    if (thumb && !index && !middle && !ring && !pinky) return "THUMB_UP"
    if (thumb && pinky && !index && !middle && !ring) return "SHAKA"
    return "UNKNOWN"
}

class Cfg(var enabled: Boolean = true, var delay: Int = 80, var cooldown: Int = 250, var sens: Int = 60)

fun defaultMappings() = mutableMapOf(
    "MOVE_CURSOR" to Cfg(true, 0, 0, 75),
    "LEFT_CLICK" to Cfg(true, 90, 220, 60),
    "RIGHT_CLICK" to Cfg(true, 200, 500, 60),
    "DRAG" to Cfg(true, 380, 0, 70),
    "SCROLL_UP" to Cfg(true, 120, 60, 55),
    "SCROLL_DOWN" to Cfg(true, 120, 60, 55),
    "ZOOM_IN" to Cfg(true, 150, 260, 50),
    "ZOOM_OUT" to Cfg(true, 150, 260, 50),
    "MAXIMIZE_WINDOW" to Cfg(true, 160, 700, 60),
    "MINIMIZE_WINDOW" to Cfg(true, 160, 700, 60),
    "SHOW_DESKTOP" to Cfg(true, 800, 1500, 60),
    "CLOSE_WINDOW" to Cfg(false, 600, 1500, 70),
    "PLAY_PAUSE" to Cfg(true, 350, 800, 65),
    "NEXT_TRACK" to Cfg(true, 120, 500, 55),
    "PREVIOUS_TRACK" to Cfg(true, 120, 500, 55),
    "VOLUME_UP" to Cfg(true, 150, 110, 50),
    "VOLUME_DOWN" to Cfg(true, 150, 110, 50),
)

class GestureIntent {
    var label = "IDLE"
    var pose = "NONE"
    var cursor: P? = null
    var drag = false
    val actions = mutableListOf<String>()
    var scroll = 0
}

class GestureEngine {
    val mappings = defaultMappings()
    var clickSensitivity = 60f
    var scrollSensitivity = 55f
    var twoHandTracking = true

    private var pose = "NONE"
    private var poseSince = 0L
    private var cand = "NONE"
    private var candCount = 0
    private val fired = mutableSetOf<String>()
    private val lastFire = mutableMapOf<String, Long>()
    private var anchor: P? = null
    private var zoomAnchor: Float? = null
    private var holdStarted: Long? = null
    private var holdIsDrag = false

    private fun cfg(g: String) = mappings[g] ?: Cfg(false, 0, 300, 50)
    private val pinchThreshold get() = 0.40f + clickSensitivity / 100f * 0.30f
    private val lThumbMin get() = 0.74f - clickSensitivity / 100f * 0.20f

    private fun canFire(g: String, now: Long, once: Boolean): Boolean {
        val c = cfg(g)
        if (!c.enabled) return false
        if (once && g in fired) return false
        return now - (lastFire[g] ?: -100000L) >= c.cooldown
    }

    private fun fire(g: String, now: Long, i: GestureIntent, once: Boolean = true): Boolean {
        if (!canFire(g, now, once)) return false
        i.actions.add(g); lastFire[g] = now
        if (once) fired.add(g)
        return true
    }

    private fun heldMs(now: Long) = (now - poseSince).toFloat()
    private fun ready(g: String, now: Long) = heldMs(now) >= cfg(g).delay

    /** hands: landmark lists (21 points each), already mirrored. now: ms (monotonic). */
    fun update(hands: List<List<P>>, now: Long): GestureIntent {
        val i = GestureIntent()
        val usable = hands.take(if (twoHandTracking) 2 else 1)
        if (usable.isEmpty()) {
            setPose("NONE", now); holdStarted = null; holdIsDrag = false
            return i
        }
        val primary = usable[0]
        val second = usable.getOrNull(1)
        var raw = detectPose(primary, pinchThreshold, lThumbMin)
        if (second != null) {
            val p2 = detectPose(second, pinchThreshold, lThumbMin)
            if (raw == "OPEN_PALM" && p2 == "OPEN_PALM") raw = "TWO_OPEN"
            else if (raw == "PINCH_INDEX" && p2 == "PINCH_INDEX") raw = "TWO_PINCH"
        }
        if (setPose(raw, now)) { anchor = null; zoomAnchor = null }
        i.pose = pose
        if (pose != "L_SHAPE" && holdStarted != null) noteLRelease(now, i, pose)

        when (pose) {
            "POINT" -> onPoint(i, primary)
            "L_SHAPE" -> onL(i, primary, now)
            "HORNS" -> { i.label = "RIGHT_CLICK"; if (ready("RIGHT_CLICK", now)) fire("RIGHT_CLICK", now, i) }
            "TWO_FINGER" -> onScroll(i, primary, now)
            "THREE_FINGER" -> onSwipe(i, primary, now)
            "FOUR_FINGER" -> onFour(i, primary, now)
            "THUMB_UP" -> { i.label = "PLAY_PAUSE"; if (ready("PLAY_PAUSE", now)) fire("PLAY_PAUSE", now, i) }
            "SHAKA" -> onVolume(i, primary, now)
            "TWO_OPEN" -> { i.label = "SHOW_DESKTOP"; if (ready("SHOW_DESKTOP", now)) fire("SHOW_DESKTOP", now, i) }
            "TWO_PINCH" -> onZoom(i, primary, second, now)
            else -> i.label = "IDLE"
        }
        return i
    }

    private fun setPose(p: String, now: Long): Boolean {
        if (p == pose) { cand = p; candCount = 0; return false }
        if (p != cand) { cand = p; candCount = 1; return false }
        candCount++
        val need = if (p == "UNKNOWN") 5 else 2
        if (candCount < need) return false
        pose = p; poseSince = now; fired.clear()
        return true
    }

    private fun onPoint(i: GestureIntent, lm: List<P>) {
        if (!cfg("MOVE_CURSOR").enabled) { i.label = "IDLE"; return }
        i.label = "MOVE_CURSOR"; i.cursor = lm[INDEX_TIP]
    }

    private fun onL(i: GestureIntent, lm: List<P>, now: Long) {
        if (holdStarted == null) holdStarted = now
        val held = now - holdStarted!!
        val dragAfter = cfg("DRAG").delay
        if (holdIsDrag || (held >= dragAfter && cfg("DRAG").enabled)) {
            holdIsDrag = true
            i.label = "DRAG"; i.drag = true; i.cursor = lm[INDEX_TIP]
        } else i.label = "LEFT_CLICK"
    }

    private fun onScroll(i: GestureIntent, lm: List<P>, now: Long) {
        val ref = lm[INDEX_MCP]
        if (anchor == null) {
            if (heldMs(now) < cfg("SCROLL_UP").delay) { i.label = "IDLE"; return }
            anchor = ref
        }
        val dy = anchor!!.y - ref.y
        val gain = 0.5f + scrollSensitivity / 55f
        val dead = 0.035f
        if (kotlin.math.abs(dy) < dead) { i.label = if (dy >= 0) "SCROLL_UP" else "SCROLL_DOWN"; return }
        val g = if (dy > 0) "SCROLL_UP" else "SCROLL_DOWN"
        i.label = g
        if (canFire(g, now, false)) {
            val n = ((kotlin.math.abs(dy) - dead) * 22f * gain).toInt().coerceIn(1, 6)
            i.scroll = if (dy > 0) n else -n
            lastFire[g] = now
        }
    }

    private fun onSwipe(i: GestureIntent, lm: List<P>, now: Long) {
        val ref = lm[INDEX_MCP]
        if (anchor == null) {
            if (heldMs(now) < cfg("NEXT_TRACK").delay) { i.label = "IDLE"; return }
            anchor = ref
        }
        val dx = ref.x - anchor!!.x
        val travel = 0.30f - cfg("NEXT_TRACK").sens / 100f * 0.18f
        i.label = "IDLE"
        if (dx > travel) { i.label = "NEXT_TRACK"; if (fire("NEXT_TRACK", now, i, false)) anchor = ref }
        else if (dx < -travel) { i.label = "PREVIOUS_TRACK"; if (fire("PREVIOUS_TRACK", now, i, false)) anchor = ref }
    }

    private fun onFour(i: GestureIntent, lm: List<P>, now: Long) {
        val ref = lm[INDEX_MCP]
        if (anchor == null) {
            if (heldMs(now) < cfg("MAXIMIZE_WINDOW").delay) { i.label = "IDLE"; return }
            anchor = ref
        }
        val dy = anchor!!.y - ref.y
        val travel = 0.26f - cfg("MAXIMIZE_WINDOW").sens / 100f * 0.14f
        i.label = "IDLE"
        if (dy > travel) { i.label = "MAXIMIZE_WINDOW"; if (fire("MAXIMIZE_WINDOW", now, i, false)) anchor = ref }
        else if (dy < -travel) { i.label = "MINIMIZE_WINDOW"; if (fire("MINIMIZE_WINDOW", now, i, false)) anchor = ref }
    }

    private fun onVolume(i: GestureIntent, lm: List<P>, now: Long) {
        val ref = lm[WRIST]
        if (anchor == null) {
            if (heldMs(now) < cfg("VOLUME_UP").delay) { i.label = "IDLE"; return }
            anchor = ref
        }
        val dy = anchor!!.y - ref.y
        if (kotlin.math.abs(dy) < 0.06f) { i.label = "IDLE"; return }
        val g = if (dy > 0) "VOLUME_UP" else "VOLUME_DOWN"
        i.label = g
        fire(g, now, i, false)
    }

    private fun onZoom(i: GestureIntent, a: List<P>, b: List<P>?, now: Long) {
        i.label = "IDLE"
        if (b == null) return
        val spread = dist(a[INDEX_TIP], b[INDEX_TIP])
        if (zoomAnchor == null) {
            if (heldMs(now) >= cfg("ZOOM_IN").delay) zoomAnchor = spread
            return
        }
        val ratio = spread / max(zoomAnchor!!, 1e-6f)
        val step = 1f + (0.32f - cfg("ZOOM_IN").sens / 100f * 0.16f)
        if (ratio > step) { i.label = "ZOOM_IN"; if (fire("ZOOM_IN", now, i, false)) zoomAnchor = spread }
        else if (ratio < 1f / step) { i.label = "ZOOM_OUT"; if (fire("ZOOM_OUT", now, i, false)) zoomAnchor = spread }
    }

    private val commandPoses = setOf("HORNS", "TWO_FINGER", "THREE_FINGER", "FOUR_FINGER", "SHAKA", "THUMB_UP", "TWO_OPEN", "TWO_PINCH")

    /** L-shape just ended: short hold = one left click, long hold was a drag. */
    private fun noteLRelease(now: Long, i: GestureIntent, newPose: String) {
        val start = holdStarted ?: return
        val held = now - start
        val wasDrag = holdIsDrag
        holdStarted = null; holdIsDrag = false
        if (wasDrag || newPose in commandPoses) return
        if (held >= cfg("LEFT_CLICK").delay) {
            fired.remove("LEFT_CLICK")
            fire("LEFT_CLICK", now, i, false)
        }
    }
}
