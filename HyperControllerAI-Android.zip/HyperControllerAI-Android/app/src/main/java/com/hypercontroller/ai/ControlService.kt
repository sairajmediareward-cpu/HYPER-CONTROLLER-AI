package com.hypercontroller.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/** Draws the on-screen cursor and turns gesture intents into taps, swipes, drags and key presses. */
class ControlService : AccessibilityService() {
    companion object {
        @Volatile var instance: ControlService? = null
        private const val MARGIN = 0.12f   // camera edge area ignored, so screen corners are reachable
    }

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private var cursor: View? = null
    private lateinit var lp: WindowManager.LayoutParams
    private var cx = 0f
    private var cy = 0f
    private val sw get() = resources.displayMetrics.widthPixels.toFloat()
    private val sh get() = resources.displayMetrics.heightPixels.toFloat()

    private var dragStroke: StrokeDescription? = null
    private var dragX = 0f
    private var dragY = 0f
    private var dragBusy = false
    private var dragEndPending = false

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        cx = sw / 2; cy = sh / 2
        val size = (36 * resources.displayMetrics.density).toInt()
        val v = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(170, 0, 200, 255))
                setStroke(4, Color.WHITE)
            }
            visibility = View.GONE
        }
        lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(v, lp)
        cursor = v
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { releaseAll() }
    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        releaseAll()
        cursor?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        cursor = null
        return super.onUnbind(intent)
    }

    /** Called on every camera frame (main thread). */
    fun handle(i: GestureIntent) {
        Bridge.pose = i.pose; Bridge.label = i.label
        val on = Bridge.controlEnabled
        cursor?.visibility = if (on) View.VISIBLE else View.GONE
        if (!on) { releaseAll(); return }

        i.cursor?.let { p ->
            val tx = ((p.x - MARGIN) / (1 - 2 * MARGIN)).coerceIn(0f, 1f) * sw
            val ty = ((p.y - MARGIN) / (1 - 2 * MARGIN)).coerceIn(0f, 1f) * sh
            cx += (tx - cx) * 0.4f
            cy += (ty - cy) * 0.4f
            moveCursorView()
        }
        val dragging = dragStroke != null
        when {
            i.drag && !dragging -> startDrag()
            i.drag -> moveDrag()
            dragging -> endDrag()          // hand left / L-shape released: never leave a finger "down"
        }
        if (i.scroll != 0) scroll(i.scroll)
        for (a in i.actions) perform(a)
    }

    fun releaseAll() {
        if (dragStroke != null) endDrag()
        cursor?.visibility = View.GONE
    }

    private fun moveCursorView() {
        val v = cursor ?: return
        lp.x = (cx - lp.width / 2f).toInt()
        lp.y = (cy - lp.height / 2f).toInt()
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
    }

    private fun perform(a: String) {
        when (a) {
            "LEFT_CLICK" -> tap(40)
            "RIGHT_CLICK" -> tap(700)                       // long-press = Android's "right click"
            "ZOOM_IN" -> pinch(true)
            "ZOOM_OUT" -> pinch(false)
            "MAXIMIZE_WINDOW" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "MINIMIZE_WINDOW", "SHOW_DESKTOP" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "CLOSE_WINDOW" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "PLAY_PAUSE" -> media(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            "NEXT_TRACK" -> media(KeyEvent.KEYCODE_MEDIA_NEXT)
            "PREVIOUS_TRACK" -> media(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            "VOLUME_UP" -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "VOLUME_DOWN" -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        }
    }

    private fun media(code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun send(vararg strokes: StrokeDescription, cb: GestureResultCallback? = null) {
        val b = GestureDescription.Builder()
        strokes.forEach { b.addStroke(it) }
        dispatchGesture(b.build(), cb, null)
    }

    private fun tap(ms: Long) {
        val p = Path().apply { moveTo(cx, cy) }
        send(StrokeDescription(p, 0, ms))
    }

    /** scroll > 0 = see content above (finger swipes down), like a mouse wheel. */
    private fun scroll(notches: Int) {
        val startY = cy.coerceIn(sh * 0.25f, sh * 0.75f)
        val endY = (startY + notches * 180f).coerceIn(sh * 0.1f, sh * 0.9f)
        val p = Path().apply { moveTo(cx, startY); lineTo(cx, endY) }
        send(StrokeDescription(p, 0, 160))
    }

    private fun pinch(zoomIn: Boolean) {
        val d0 = if (zoomIn) 40f else 240f
        val d1 = if (zoomIn) 240f else 40f
        fun x(v: Float) = v.coerceIn(1f, sw - 1)
        val a = Path().apply { moveTo(x(cx - d0), cy); lineTo(x(cx - d1), cy) }
        val b = Path().apply { moveTo(x(cx + d0), cy); lineTo(x(cx + d1), cy) }
        send(StrokeDescription(a, 0, 300), StrokeDescription(b, 0, 300))
    }

    // ---- drag: one long stroke continued piece by piece ---------------------
    private val dragCb = object : GestureResultCallback() {
        override fun onCompleted(g: GestureDescription?) { dragBusy = false; if (dragEndPending) endDrag() }
        override fun onCancelled(g: GestureDescription?) { dragBusy = false; dragStroke = null; dragEndPending = false }
    }

    private fun startDrag() {
        dragX = cx; dragY = cy
        val s = StrokeDescription(Path().apply { moveTo(dragX, dragY) }, 0, 10, true)
        dragStroke = s; dragBusy = true
        send(s, cb = dragCb)
    }

    private fun moveDrag() {
        val s = dragStroke ?: return
        if (dragBusy) return
        val n = s.continueStroke(Path().apply { moveTo(dragX, dragY); lineTo(cx, cy) }, 0, 30, true)
        dragX = cx; dragY = cy
        dragStroke = n; dragBusy = true
        send(n, cb = dragCb)
    }

    private fun endDrag() {
        val s = dragStroke ?: run { dragEndPending = false; return }
        if (dragBusy) { dragEndPending = true; return }
        val n = s.continueStroke(Path().apply { moveTo(dragX, dragY); lineTo(cx, cy) }, 0, 10, false)
        dragStroke = null; dragEndPending = false
        send(n, cb = dragCb)
    }
}
