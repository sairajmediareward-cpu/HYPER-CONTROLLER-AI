plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hypercontroller.ai"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.hypercontroller.ai"
        minSdk = 26          // continued drag gestures need API 26+
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += "task" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}

// Downloads MediaPipe's hand model once (needs internet on the build machine).
val modelFile = file("src/main/assets/hand_landmarker.task")
tasks.register("downloadModel") {
    outputs.file(modelFile)
    doLast {
        if (!modelFile.exists()) {
            modelFile.parentFile.mkdirs()
            val url = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
            java.net.URI(url).toURL().openStream().use { i -> modelFile.outputStream().use { o -> i.copyTo(o) } }
        }
    }
}
tasks.named("preBuild") { dependsOn("downloadModel") }
